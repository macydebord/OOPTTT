public enum GameState
{
    WIN("Congratulations! You win!"),
    DRAW("It's a draw."),
    CONTINUE("");

    private String message;

    GameState(String message)
    {
        this.message = message;
    }

    public String getMessage()
    {
        return message;
    }
}

public class Game
{
    private TTTBoard board;
    private Player currentPlayer;

    public Game()
    {
        board = new TTTBoard();
        currentPlayer = Player.X;
    }

    public void makeMove(int row, int col)
    {
        board.makeMove(row, col, currentPlayer.getMark());
        currentPlayer = (currentPlayer == Player.X) ? Player.O : Player.X;
    }

    public GameState checkGameStatus()
    {
        if (board.checkWin())
        {
            return GameState.WIN;
        } else if (board.isFull())
        {
            return GameState.DRAW;
        }
        return GameState.CONTINUE;
    }

    public Player getCurrentPlayer()
    {
        return currentPlayer;
    }

    public void reset()
    {
        board.clear();
        currentPlayer = Player.X;
    }
}


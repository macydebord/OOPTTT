import javax.swing.*;
import java.awt.*;

public class TicTacToeGUI extends JFrame
{
    private Game game;

    public TicTacToeGUI()
    {
        game = new Game();

        JPanel boardPanel = new JPanel(new GridLayout(3, 3));
        for (int row = 0; row < 3; row++)
        {
            for (int col = 0; col < 3; col++)
            {
                TTTTileButton button = new TTTTileButton(row, col);
                button.addActionListener(e ->
                {
                    TTTTileButton clickedButton = (TTTTileButton) e.getSource();
                    if (!clickedButton.isClicked())
                    {
                        game.makeMove(clickedButton.getRow(), clickedButton.getCol());
                        clickedButton.setClicked(true);
                        clickedButton.setText(game.getCurrentPlayer().toString());
                        GameState state = game.checkGameStatus();
                        if (state == GameState.WIN || state == GameState.DRAW)
                        {
                            JOptionPane.showMessageDialog(null, state.getMessage());
                            resetGame();
                        }
                    }
                });
                boardPanel.add(button);
            }
        }

        this.add(boardPanel);
        this.setTitle("Tic Tac Toe");
        this.setSize(300, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    private void resetGame()
    {
        game.reset();
        for (java.awt.Component component : getContentPane().getComponents())
        {
            if (component instanceof TTTTileButton)
            {
                TTTTileButton button = (TTTTileButton) component;
                button.setText("");
                button.setClicked(false);
            }
        }
    }

    public static void main(String[] args)
    {
        new TicTacToeGUI();
    }
}

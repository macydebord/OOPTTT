import javax.swing.*;

public class TTTTileButton extends JButton {
    private int row;
    private int col;
    private boolean clicked;

    public TTTTileButton(int row, int col) {
        this.row = row;
        this.col = col;
        this.clicked = false;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean isClicked() {
        return clicked;
    }

    public void setClicked(boolean clicked) {
        this.clicked = clicked;
    }
}

public enum Player
{
    X('X'),
    O('O');

    private char mark;

    Player(char mark)
    {
        this.mark = mark;
    }

    public char getMark()
    {
        return mark;
    }

    @Override
    public String toString()
    {
        return Character.toString(mark);
    }
}

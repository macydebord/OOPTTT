public class TTTBoard
{
    private char[][] boardState;

    public TTTBoard()
    {
        boardState = new char[3][3];
    }

    public void makeMove(int row, int col, char mark)
    {
        boardState[row][col] = mark;
    }

    public boolean checkWin()
    {
        for (int i = 0; i < 3; i++)
        {
            if (boardState[i][0] == boardState[i][1] && boardState[i][1] == boardState[i][2] && boardState[i][0] != '\u0000')
            {
                return true;
            }
        }
        for (int i = 0; i < 3; i++)
        {
            if (boardState[0][i] == boardState[1][i] && boardState[1][i] == boardState[2][i] && boardState[0][i] != '\u0000')
            {
                return true;
            }
        }
        if ((boardState[0][0] == boardState[1][1] && boardState[1][1] == boardState[2][2] && boardState[0][0] != '\u0000') ||
                (boardState[0][2] == boardState[1][1] && boardState[1][1] == boardState[2][0] && boardState[0][2] != '\u0000'))
        {
            return true;
        }

        return false;
    }

    public boolean isFull()
    {
        for (char[] row : boardState)
        {
            for (char tile : row)
            {
                if (tile == '\u0000')
                {
                    return false;
                }
            }
        }
        return true;
    }

    public void clear()
    {
        boardState = new char[3][3];
    }
}
